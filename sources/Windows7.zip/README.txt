### - Fichier téléchargée à partir de kevfr8.github.io

Ce pack contient l'ISO de Windows 7 Édition Intégrale et de deux mises à jours pour réparer le problème de l'installation de VMware Tools.

Il est à noter que depuis le 14 janvier 2020, le support de Windows 7 à fermée définitivement. Cela implique en outre,

❌ - L'abandon des mises à jour de sécurités.

❌ - Certains programmes, ne seront plus mis à jours.

❌ - Windows 7 est vulnérable aux attaques potentielles de virus.

❌ - Vos pilotes ne pourront plus etre mis à jour.

Cependant, il n'y a pas que de mauvaises choses,

✔ - Vous pouvez encore utiliser Windows 7

✔ - La communauté de Windows 7, sera encore présente pour rendre W7 utilisable (comme le cas de Windows Vista ou de Windows XP)

✔ - Vous pouvez encore profiter d'Aero Glass, des jeux intégrée (Purble Place, démineur,...).

✔ - Vous pouvez migrer vers Linux pour redonner une seconde chance à votre vieux PC.

Si vous avez rencontré des problèmes durant l'installation, vous pouvez me contacter via mon mail ou directement sur ma vidéo.







